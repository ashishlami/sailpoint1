
EMAIL FRAMEWORK README

Quick Deployment Steps:
1. Update calling workflow to call SP Dynamic Send Emails Sub **.  Input vars are:
	- identityName
	- emailArgList

